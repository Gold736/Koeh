package com.example.aihelper

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.util.Base64
import java.io.ByteArrayOutputStream
import kotlin.math.max
import kotlin.math.min

/**
 * Демонстрация экрана. Пока она включена, система зеркалит экран в маленький буфер.
 * Ничего никуда не отправляется, пока вы сами не зададите вопрос: тогда берётся
 * ОДИН последний кадр и уходит в Claude вместе с вашим вопросом.
 */
class ScreenShare(private val ctx: Context, private val ui: Handler) {

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var held: Image? = null   // последний кадр

    val isOn: Boolean get() = projection != null

    fun start(resultCode: Int, data: Intent, maxSide: Int, onStopped: () -> Unit) {
        stop()
        val mpm = ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = mpm.getMediaProjection(resultCode, data) ?: return
        // Android 14+: колбэк нужно зарегистрировать до создания виртуального экрана
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stop()
                onStopped()
            }
        }, ui)

        val dm = ctx.resources.displayMetrics
        val scale = min(1f, maxSide.toFloat() / max(dm.widthPixels, dm.heightPixels))
        val w = (dm.widthPixels * scale).toInt().coerceAtLeast(2)
        val h = (dm.heightPixels * scale).toInt().coerceAtLeast(2)

        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        r.setOnImageAvailableListener({ rd ->
            val img = rd.acquireLatestImage() ?: return@setOnImageAvailableListener
            held?.close()
            held = img
        }, ui)
        display = mp.createVirtualDisplay(
            "aihelper-share", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            r.surface, null, ui
        )
        reader = r
        projection = mp
    }

    /** Последний кадр как JPEG в base64 или null, если кадра нет. */
    fun grabJpegBase64(): String? {
        val img = held ?: return null
        return runCatching {
            val plane = img.planes[0]
            plane.buffer.rewind()
            val rowPadding = plane.rowStride - plane.pixelStride * img.width
            val full = Bitmap.createBitmap(
                img.width + rowPadding / plane.pixelStride, img.height, Bitmap.Config.ARGB_8888
            )
            full.copyPixelsFromBuffer(plane.buffer)
            val bmp = Bitmap.createBitmap(full, 0, 0, img.width, img.height)
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 75, out)
            Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        }.getOrNull()
    }

    fun stop() {
        val mp = projection
        projection = null
        held?.close()
        held = null
        display?.release()
        display = null
        reader?.close()
        reader = null
        runCatching { mp?.stop() }
    }
}
